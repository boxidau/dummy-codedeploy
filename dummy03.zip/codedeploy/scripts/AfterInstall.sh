#!/bin/bash

/usr/sbin/service httpd restart
